//
//  GCTriathlons.h
//  weekFourThu
//
//  Created by Collins on 12/3/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GCTriathlons : NSObject

@property (nonatomic, copy, readonly, nonnull)NSString *categoryName;
@property (nonatomic, copy, readonly, nonnull)NSString *fieldLimit;
@property (nonatomic, copy, readonly, nonnull)NSString *startTime;

- (instancetype)initWithCategoryName:(NSString *)categoryName
                          fieldLimit:(NSString *)fieldLimit
                           startTime:(NSString *)startTime;
@end

@interface GCTriathlons (JSONConvertable)

- (instancetype)initWithDictionary:(NSDictionary<NSString *, id> *)dictionary;

@end

NS_ASSUME_NONNULL_END
