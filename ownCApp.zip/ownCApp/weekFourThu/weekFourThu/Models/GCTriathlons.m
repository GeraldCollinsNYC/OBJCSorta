//
//  GCTriathlons.m
//  weekFourThu
//
//  Created by Collins on 12/3/20.
//

#import "GCTriathlons.h"

static NSString *const CategoryName = @"categoryName";
static NSString *const FieldLimit = @"fieldLimit";
static NSString *const StartTime = @"startTime";

@implementation GCTriathlons

- (instancetype)initWithCategoryName:(NSString *)categoryName fieldLimit:(NSString *)fieldLimit startTime:(NSString *)startTime
{
    self = [super init];
    if (self)
    {
        _categoryName = categoryName;
        _fieldLimit = fieldLimit;
        _startTime = startTime;
    }
    return self;
}

@end


@implementation GCTriathlons (JSONConvertable)

- (instancetype)initWithDictionary:(NSDictionary<NSString *,id> *)dictionary
{
    NSString *categoryName = dictionary[CategoryName];
    NSString *fieldLimit = dictionary[FieldLimit];
    NSString *startTime = dictionary[StartTime];
    
    return [self initWithCategoryName:categoryName fieldLimit:fieldLimit startTime:startTime];
}

@end

