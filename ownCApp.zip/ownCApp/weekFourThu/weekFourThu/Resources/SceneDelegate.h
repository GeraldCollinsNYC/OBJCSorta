//
//  SceneDelegate.h
//  weekFourThu
//
//  Created by Collins on 12/3/20.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

