//
//  GCTriathlonsController.h
//  weekFourThu
//
//  Created by Collins on 12/3/20.
//

#import <Foundation/Foundation.h>
#import "GCTriathlons.h"

NS_ASSUME_NONNULL_BEGIN

@interface GCTriathlonsController : NSObject

+ (instancetype)sharedInstance;

@property(nonatomic, copy) NSArray<GCTriathlons *> *triathlons;

- (void)fetchTriathlons:(void(^) (BOOL))completion;

@end

NS_ASSUME_NONNULL_END
