//
//  GCTriathlonsController.m
//  weekFourThu
//
//  Created by Collins on 12/3/20.
//

#import "GCTriathlonsController.h"

static NSString *const baseURL = @"https://www.trireg.com/api/search";
static NSString *const searchQuery = @"MatchingEvents";
//static NSString *const eventsQueryKey = @"MatchingEvents";


@implementation GCTriathlonsController

+ (instancetype)sharedInstance
{
    static GCTriathlonsController *sharedInstance = nil;
    static dispatch_once_t onceToken;
    _dispatch_once(&onceToken, ^{
        sharedInstance = [GCTriathlonsController new];
    });
    return sharedInstance;
}

- (void)fetchTriathlons:(void (^)(BOOL))completion
{
    NSURL *url = [NSURL URLWithString:baseURL];
    NSURL *finalURL = [url URLByAppendingPathComponent:searchQuery];
    
    [[[NSURLSession sharedSession] dataTaskWithURL:finalURL completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        {
            if (error)
            {
                NSLog(@"%@", error.localizedDescription);
                return completion(false);
            }
            if (response)
            {
                NSLog(@"%@", response);
            }
            if (!data)
            {
                NSLog(@"%@", error.localizedDescription);
                return completion(false);
            }
            
            NSDictionary *topLevelJSON = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
            
            if (!topLevelJSON)
            {
                NSLog(@"%@", error.localizedDescription);
                return completion(false);
            }
            
            NSDictionary *secondLevelJSON = topLevelJSON[@"JSON"];
            
            NSArray<NSDictionary *> *thirdLevelJSON = secondLevelJSON[@"MatchingEvents"];
            
            NSMutableArray *arrayOfTriathlons = [NSMutableArray new];
            
            for (NSDictionary *currentDictionary in thirdLevelJSON)
            {
                NSDictionary *triathlonsDictionary = currentDictionary[@"Categories"];
                GCTriathlons *triathlons = [[GCTriathlons alloc] initWithDictionary:triathlonsDictionary];
                [arrayOfTriathlons addObject:triathlons];
            }
            
            if (arrayOfTriathlons.count !=0)
            {
                GCTriathlonsController.sharedInstance.triathlons = arrayOfTriathlons;
                completion(true);
            } else {
                completion(false);
            }
            
        }
    }] resume];
}
@end

